package cl.ejemplo_clase4.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestClaseApplicationTests {

	@Test
	void contextLoads() {
	}

}

package cl.ejemplo_clase4.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestClaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestClaseApplication.class, args);
	}

}
